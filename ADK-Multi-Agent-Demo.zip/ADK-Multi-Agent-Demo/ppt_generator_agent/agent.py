
from google.adk.agents import LlmAgent

from ppt_generator_agent.tools import get_wikipedia_content, create_dynamic_presentation

 
model="gemini-2.0-flash-exp"

# The agent will use the get_wikipedia_content tool to fetch the content of the Wikipedia page.
wikipedia_agent = LlmAgent(
    name="wikipedia_agent",
    model=model,
    description=(
        "Agent to search any Wikipedia page and return the complete content."
        ),
    instruction=(
        "You are an agent that can search Wikipedia pages and return the complete content by using the given tool."
        ),
    tools=[get_wikipedia_content],
    output_key="data"  # This is the key where the output of the tool will be stored in the state
)

# This agent will use the output of the wikipedia agent to create a dynamic presentation
generate_ppt_agent = LlmAgent(
    name="generate_ppt_agent",
    model=model,
    description=(
        """Generates a PowerPoint presentation based on the provided specification.
        The specification includes a title and a list of slides with varying layouts and content.
        The agent can handle title-only slides, title + content slides, bullet point slides, and image slides."""  
    ),
    instruction=(
        """Get complete data from state key 'data', according to the data, create a json input for the create_dynamic_presentation tool. Include all the required data for the presentation.
        To create the dynamic input JSON for the PowerPoint generation function, you need to define a dictionary that includes a presentation "title" and a list of "slides", where each slide is a dictionary specifying its "layout" and relevant content fields. The layout determines which keys are required: for example, a "title_only" layout needs only a "title"; a "title_content" layout needs both "title" and "content"; a "bullet_slide" requires a "title" and a list of "bullets"; and an "image_slide" should include a "title" and an "image" URL. You can dynamically generate this JSON from user input, form data, or another structured source by appending slide dictionaries to the "slides" list according to the desired content and layout. The complete dictionary can then be passed to the function as ppt_spec. Include as much detailed information as possible in the json.
        Example json:
        {
        "title": "Dynamic Presentation Demo",
        "slides": [
            {
                "layout": "title_only",
                "title": "Welcome to the Demo"
            },
            {
                "layout": "title_content",
                "title": "Overview",
                "content": "This slide explains how dynamic layouts can adapt based on content from an LLM."
            },
            {
                "layout": "bullet_slide",
                "title": "Key Points",
                "bullets": [
                    "Different layouts based on input",
                    "Adaptive slide creation",
                    "Easy integration with agentic systems"
                ]
            },
            {
                "layout": "image_slide",
                "title": "Featured Image",
                "image": ""
            }
        ]
    }
    After this json is created, use the tool: create_dynamic_presentation to create the presentation with the json as an input to the tool."""   
    ),
    tools=[create_dynamic_presentation]
)

# This agent will use the wikipedia agent and generate_ppt_agent and provide the final output
root_agent = LlmAgent(
    name="orchestrator_agent",
    description=(
        "Agent to retrieve Wikipedia content and generate a PowerPoint presentation based on that content."
    ),
    model=model,
    sub_agents=[wikipedia_agent,generate_ppt_agent]   
)



