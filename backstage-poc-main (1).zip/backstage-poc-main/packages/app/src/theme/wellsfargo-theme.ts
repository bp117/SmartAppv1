import { createTheme, lightTheme, genPageTheme, shapes } from "@backstage/theme";

const myTheme = createTheme({
    palette: {
      ...lightTheme.palette,
      primary: {
        main: '#403c3a',
      },
      secondary: {
        main: '#565a6e',
      },
      error: {
        main: '#ff755e',
      },
      warning: {
        main: '#ff9657',
      },
      info: {
        main: '#9a89d9',
      },
      success: {
        main: '#49b876',
      },
      background: {
        default: '#f9f7f6',
        paper: '#f9f7f6',
      },
      banner: {
        info: '#9a89d9',
        error: '#ff755e',
        text: '#343b58',
        link: '#565a6e',
      },
      errorBackground: '#ff755e',
      warningBackground: '#ff9657',
      infoBackground: '#343b58',
      navigation: {
        background: '#d71e28',
        indicator: '#ffcd41',
        color: '#f9f7f6',
        selectedColor: '#ffffff',
      },
    },
    defaultPageTheme: 'home',

    /* below drives the header colors */

    pageTheme: {
    home: genPageTheme({ colors: ['#d71e28', '#ffcd41'], shape: shapes.wave }),
    documentation: genPageTheme({
      colors: ['#d71e28', '#ffcd41'],
      shape: shapes.wave2,
    }),
    tool: genPageTheme({ colors: ['#d71e28', '#ffcd41'], shape: shapes.round }),
    service: genPageTheme({
      colors: ['#d71e28', '#ffcd41'],
      shape: shapes.wave,
    }),
    website: genPageTheme({
      colors: ['#d71e28', '#ffcd41'],
      shape: shapes.wave,
    }),
    library: genPageTheme({
      colors: ['#d71e28', '#ffcd41'],
      shape: shapes.wave,
    }),
    other: genPageTheme({ colors: ['#d71e28', '#ffcd41'], shape: shapes.wave }),
    app: genPageTheme({ colors: ['#d71e28', '#ffcd41'], shape: shapes.wave }),
    apis: genPageTheme({ colors: ['#d71e28', '#ffcd41'], shape: shapes.wave }),
  },
  });

  export const wfTheme = myTheme;