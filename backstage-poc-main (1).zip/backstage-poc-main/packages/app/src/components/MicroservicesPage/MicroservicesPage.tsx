import {
    Content,
    ContentHeader,
    CreateButton,
    PageWithHeader,
    SupportButton,
    TableColumn,
    TableProps,
  } from '@backstage/core-components';
  import { configApiRef, useApi, useRouteRef } from '@backstage/core-plugin-api';
  import { CatalogTable, CatalogTableRow } from '@backstage/plugin-catalog';
  import {
    EntityKindPicker,
    EntityLifecyclePicker,
    EntityListProvider,
    EntityOwnerPicker,
    EntityTagPicker,
    EntityTypePicker,
    UserListFilterKind,
    UserListPicker,
    CatalogFilterLayout,
    catalogApiRef,
  } from '@backstage/plugin-catalog-react';
  import React, { useEffect, useState } from 'react';
  import { registerComponentRouteRef } from './routes';
  import axios from 'axios';
import { Button } from '@material-ui/core';
import { Margin } from '@mui/icons-material';

  console.log('Testing');
  const defaultColumns: TableColumn<CatalogTableRow>[] = [
    {
      title: 'ID',
      highlight: true,
      render: (rowData: CatalogTableRow) => {
        const [id, setId] = useState<string>('');
  
        useEffect(() => {
          async function fetchData() {
            // console.log(rowData.entity.metadata.name);
              const response = await fetch(`http://localhost:7007/api/my-custom-plugin/catalog/${rowData.entity.metadata.name}`);
              const data = await response.json();
              if(!data.response.statusCode){
                setId(data.response);
              }

          }
          fetchData();
        }, [rowData]);
  
        const detailsUrl = `http://localhost:3000/catalog/${rowData.entity.metadata.namespace}/${rowData.entity.kind}/${rowData.entity.metadata.name}`;
       
        const [isHovered, setIsHovered] = useState(false);
      
        const linkStyles = {
          textDecoration: isHovered ? 'underline' : 'none',
        };
        return  <a
        href={detailsUrl}
        style={linkStyles}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {id}
      </a>;
      }
    },
    CatalogTable.columns.createTitleColumn({ hidden: true }),
    CatalogTable.columns.createNameColumn({ defaultKind: 'Component'}),
    CatalogTable.columns.createSystemColumn(),
    CatalogTable.columns.createOwnerColumn(),
    CatalogTable.columns.createSpecTypeColumn(),
    CatalogTable.columns.createTagsColumn(),
    {
      title: 'App Id',
      render: (rowData) => {
        return rowData.entity.metadata.appID
      }
      
    },
    CatalogTable.columns.createSpecLifecycleColumn()
  ];
  
  /**
   * DefaultCatalogExplorerPageProps
   * @public
   */
  export type DefaultCatalogExplorerPageProps = {
    initiallySelectedFilter?: UserListFilterKind;
    columns?: TableColumn<CatalogTableRow>[];
    actions?: TableProps<CatalogTableRow>['actions'];
  };
  
  /**
   * DefaultCatalogExplorerPage
   * @public
   */
  export const DefaultMicroservicesPage = (props: DefaultCatalogExplorerPageProps) => {
    const { initiallySelectedFilter = 'all', columns, actions } = props;
    const generatedSubtitle = `Microservices Explorer`;
  
    return (
      <PageWithHeader
        themeId="apis"
        title="Microservices"
        subtitle={generatedSubtitle}
        pageTitleOverride="Microservices Catalog"
      >
        <Content>
        <ContentHeader title="">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <CreateButton title="Create" to={'/create'} />
              </div>
              <div style={{ marginLeft: '8px' }}>
                <CreateButton title="Register Microservice" to={'/catalog-import'} />
              </div>
            </div>
          <SupportButton>All your Microservices</SupportButton>
        </ContentHeader>

          
          <EntityListProvider>
            <CatalogFilterLayout>
              <CatalogFilterLayout.Filters>
                <EntityKindPicker initialFilter="component" hidden />
                <EntityTypePicker initialFilter="service" hidden/>
                <UserListPicker initialFilter={initiallySelectedFilter} />
                <EntityOwnerPicker />
                <EntityLifecyclePicker />
                <EntityTagPicker />
              </CatalogFilterLayout.Filters>
              <CatalogFilterLayout.Content>
                <CatalogTable
                  columns={columns || defaultColumns}
                  actions={actions}
                />
              </CatalogFilterLayout.Content>
            </CatalogFilterLayout>
          </EntityListProvider>
        </Content>
      </PageWithHeader>
    );
  };
