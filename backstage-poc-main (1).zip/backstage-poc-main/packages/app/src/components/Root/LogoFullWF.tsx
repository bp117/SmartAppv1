import { makeStyles } from '@material-ui/core/styles';
import React from 'react';
import LogoPNG from './logo.png'

const useStyles = makeStyles({
    img: {
      width: 'auto',
      height: 25,
    },
  });

const LogoFullWF = () => {
    const classes = useStyles();
  
    return (<img className={classes.img} src={LogoPNG} /> );
  };

export default LogoFullWF;