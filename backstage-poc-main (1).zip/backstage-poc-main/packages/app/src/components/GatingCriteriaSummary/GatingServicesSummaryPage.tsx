import React, { useState, useEffect } from 'react';
import { useEntity } from '@backstage/plugin-catalog-react';
import { Table, TableColumn } from '@backstage/core-components';
import LaunchSharp from '@material-ui/icons/LaunchSharp';

import { Chip, Modal, Typography } from '@material-ui/core';
import { VisibilitySharp } from '@mui/icons-material';

const GatingServicesSummaryPage = () => {

  const { entity } = useEntity();
  const [values, setValues] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [open, setOpen] = useState(false);
  const [detailsOfValues,setDetailsOfValues] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch(
        `http://localhost:7007/api/my-custom-plugin/catalog/${entity.metadata.name}/summary`,
      );
      const data = await response.json();
      const sortedData = data.response.sort((a: { summary_value: string; }, b: { summary_value: string; }) => {
        if (a.summary_value === "Success") return -1;
        if (b.summary_value === "Success") return 1;
        if (a.summary_value === "Fail") return 1;
        if (b.summary_value === "Fail") return -1;
        return 0;
      });
      setValues(sortedData);
    };

    // Call the function
    fetchData();
  }, []);

  const handleRowClick = async (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>, rowData: React.SetStateAction<null>) => {
    event.preventDefault();
    setSelectedRow(rowData);
    setOpen(true);
    if(rowData){
      const metrics = rowData.metrics;
      const url = `http://localhost:7007/api/my-custom-plugin/catalog/${entity.metadata.name}/getAllDetails/${metrics}`;
      const response = await fetch(url);
      const data = await response.json();
      setDetailsOfValues(data.response);
      console.log(detailsOfValues);
    }
  };

  const handleClose = () => {
    setOpen(false);
  };

  const columns: TableColumn[] = [
    {
      title: 'Metrics',
      field: 'metrics',
      highlight: true,
    },
    {
      title: 'Result',
      field: 'summary_value',
      render: rowData =>(
        <Chip
          label ={rowData.summary_value}
          style = {{backgroundColor: rowData.summary_value=="Success" ? 'green' : rowData.summary_value=="NA"? 'grey' : 'red' ,color:'white',width: '85px'}}
        />
      )
    },
    {
      title: 'Details',
      field: 'link',
      render: rowData => (
        <a href="#" onClick={event => handleRowClick(event, rowData)}>
          <VisibilitySharp  />
        </a>
      ),
    },
  ];

  return (
    <div className="App">
      <Table
        options={{ paging: true }}
        data={values}
        columns={columns}
        title="Microservice Gating Critera Summary"
      />
      <Modal open={open} onClose={handleClose}>
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: '#FFF', padding: '20px', borderRadius: '10px' }}>
          <Typography variant="h3" component="h3" gutterBottom>
            {selectedRow && selectedRow.metrics}
          </Typography>
          {selectedRow && 
            <table style={{ borderCollapse: 'collapse', width: '100%' }}>
              <thead>
                <tr style={{ backgroundColor: '#F1F1F1', fontWeight: 'bold' }}>
                  <td style={{ padding: '10px', textAlign: 'left' }}>Key</td>
                  <td style={{ padding: '10px', textAlign: 'left' }}>Value</td>
                </tr>
              </thead>
              <tbody>
                {detailsOfValues.map((item) => (
                  <tr key={item.key}>
                    <td style={{ padding: '10px', border: '1px solid #ddd', fontWeight: 'bold' }}>
                      {item.key}
                    </td>
                    <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                      {item.value}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          }
        </div>
      </Modal>
    </div>
  );
};

export default GatingServicesSummaryPage;



