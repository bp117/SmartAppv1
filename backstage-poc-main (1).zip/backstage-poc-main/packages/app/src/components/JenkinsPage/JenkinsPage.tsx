
import {Link, Table, TableColumn } from '@backstage/core-components';
import { Box, IconButton, Tooltip, Typography } from '@material-ui/core';
import RetryIcon from '@material-ui/icons/Replay';
import { default as React, useState } from 'react';
import { Project } from './jenkins_interfaces';
let demoData = require('./data.json')

const FailCount = ({ count }: { count: number }): JSX.Element | null => {
    if (count !== 0) {
      return <>{count} failed</>;
    }
    return null;
  };
  
  const SkippedCount = ({ count }: { count: number }): JSX.Element | null => {
    if (count !== 0) {
      return <>{count} skipped</>;
    }
    return null;
  };

const FailSkippedWidget = ({
    skipped,
    failed,
  }: {
    skipped: number;
    failed: number;
  }): JSX.Element | null => {
    if (skipped === 0 && failed === 0) {
      return null;
    }
  
    if (skipped !== 0 && failed !== 0) {
      return (
        <>
          {' '}
          (<FailCount count={failed} />, <SkippedCount count={skipped} />)
        </>
      );
    }
  
    if (failed !== 0) {
      return (
        <>
          {' '}
          (<FailCount count={failed} />)
        </>
      );
    }
  
    if (skipped !== 0) {
      return (
        <>
          {' '}
          (<SkippedCount count={skipped} />)
        </>
      );
    }
  
    return null;
  };

  import {
    StatusPending,
    StatusRunning,
    StatusOK,
    StatusWarning,
    StatusAborted,
    StatusError,
  } from '@backstage/core-components';
import { stringify } from 'querystring';
  
  export const JenkinsRunStatus = ({
    status,
  }: {
    status: string | undefined;
  }) => {
    if (status === undefined) return null;
    switch (status.toLocaleLowerCase('en-US')) {
      case 'queued':
      case 'scheduled':
        return (
          <>
            <StatusPending /> Queued
          </>
        );
      case 'running':
        return (
          <>
            <StatusRunning /> In progress
          </>
        );
      case 'unstable':
        return (
          <>
            <StatusWarning /> Unstable
          </>
        );
      case 'failure':
        return (
          <>
            <StatusError /> Failed
          </>
        );
      case 'success':
        return (
          <>
            <StatusOK /> Completed
          </>
        );
      case 'aborted':
        return (
          <>
            <StatusAborted /> Aborted
          </>
        );
      default:
        return (
          <>
            <StatusWarning /> {status}
          </>
        );
    }
  };

/* const demoData=[{
    timestamp: 123123,
    fullName: 'org/jobname/buildnumber',
    branchName: 'last build/commit id',
    status:  <><StatusOK />Completed</>,
    tests: '1/1 Passed'
},{
    timestamp: 123123,
    fullName: 'org/jobname/buildnumber',
    branchName: 'last build/commit id',
    status:  <><StatusRunning />In Progress</>,
    tests: 'na'

},{
    timestamp: 123123,
    fullName: 'org/jobname/buildnumber',
    branchName: 'last build/commit id',
    status:  <><StatusAborted />Failed</>,
    tests: '0/1 Passed'

},
{
    timestamp: 123123,
    fullName: 'org/jobname/buildnumber',
    branchName: 'last build/commit id',
    status:  <><StatusPending />Queued</>,
    tests: 'na'

}] */

const generatedColumns: TableColumn[] = [
    {
      title: 'Timestamp',
      defaultSort: 'desc',
      hidden: true,
      field: 'lastBuild.timestamp',
    },
    {
      title: 'Build',
      field: 'fullName',
      highlight: true,
      render: (row: Partial<Project>) => {
        const LinkWrapper = () => {
          if (!row.fullName || !row.lastBuild?.number) {
            return (
              <>
                {row.fullName ||
                  row.fullDisplayName ||
                  row.displayName ||
                  'Unknown'}
              </>
            );
          }
  
          return (
            <Link
              to={stringify({
                jobFullName: encodeURIComponent(row.fullName),
                buildNumber: String(row.lastBuild?.number),
              })}
            >
              {row.fullDisplayName}
            </Link>
          );
        };
        return <LinkWrapper />;
      },
      },
    {
      title: 'Source',
      field: 'branchName',
      render: (row: Partial<Project>) => (
        <>
          <Typography paragraph>
            <Link to={row.lastBuild?.source?.url ?? ''}>
              {row.lastBuild?.source?.branchName}
            </Link>
          </Typography>
          <Typography paragraph>{row.lastBuild.source.commit.hash}</Typography>
        </>
      ),
    },
    {
      title: 'Status',
      field: 'status',
      render: (row: Partial<Project>) => {
        return (
          <Box display="flex" alignItems="center">
            <JenkinsRunStatus status={row.status} />
          </Box>
        );
      },
    },
    {
      title: 'Tests',
      sorting: false,
      field: 'tests',
      render: (row: Partial<Project>) => {
        return (
          <>
            <Typography paragraph>
              {row.lastBuild?.tests && (
                <Link to={row.lastBuild?.tests.testUrl ?? ''}>
                  {row.lastBuild?.tests.passed} / {row.lastBuild?.tests.total}{' '}
                  passed
                  <FailSkippedWidget
                    skipped={row.lastBuild?.tests.skipped}
                    failed={row.lastBuild?.tests.failed}
                  />
                </Link>
              )}
  
              {!row.lastBuild?.tests && 'n/a'}
            </Typography>
          </>
        );
      },
    },
    {
      title: 'Actions',
      sorting: false,
      render: () => {
        const ActionWrapper = () => {
          return (
            <Tooltip title="Rerun build">
              <>
                  <IconButton>
                    <RetryIcon />
                  </IconButton>
              </>
            </Tooltip>
          );
        };
        return <ActionWrapper />;
      },
      width: '10%',
    },
  ];
  
  export const JenkinsPage = () => {
    return (
        <Table
          actions={[
            {
              icon: () => <RetryIcon />,
              tooltip: 'Refresh Data',
              isFreeAction: true,
              onClick: () => {},
            },
          ]}
          data={demoData}
          title={
            <Box display="flex" alignItems="center">
              <Typography variant="h6">Build Status Page</Typography>
            </Box>
          }
          columns={generatedColumns}
        />
      );
    };