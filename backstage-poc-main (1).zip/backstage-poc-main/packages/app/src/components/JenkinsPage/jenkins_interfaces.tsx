export interface Build {
    // standard Jenkins
    timestamp: number;
    building: boolean;
    duration: number;
    result?: string;
    fullDisplayName: string;
    displayName: string;
    url: string;
    number: number;
  
    // added by us
    source?: {
      branchName: string;
      displayName: string;
      url: string;
      commit: {
        hash: string;
      };
      author: string;
    };
    tests: {
      passed: number;
      skipped: number;
      failed: number;
      total: number;
      testUrl: string;
    };
    status: string; // == building ? 'running' : result,
  }
  
  export interface Project {
    // standard Jenkins
    lastBuild: Build;
    displayName: string;
    fullDisplayName: string;
    fullName: string;
    inQueue: string;
    // added by us
    status: string; // == inQueue ? 'queued' : lastBuild.building ? 'running' : lastBuild.result,
    // TODO rename to handle.* ? also, should this be on lastBuild?
  }