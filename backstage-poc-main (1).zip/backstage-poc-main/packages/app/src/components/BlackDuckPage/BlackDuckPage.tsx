import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Table,
  TableColumn
} from '@backstage/core-components';
import LaunchSharp from '@material-ui/icons/LaunchSharp';
import { Link } from '@backstage/core-components';
import { Chip } from '@material-ui/core';
import dataFromJson from './sample.json';

const useStyles = makeStyles(theme => ({
  chipLabel: {
    color: theme.palette.common.white,
  },
  chipHigh: {
    margin: 0,
    backgroundColor: 'FF0000',
  },
  chipCritical: {
    margin: 0,
    backgroundColor: '#9c251f',
  },
  chipMedium: {
    margin: 0,
    backgroundColor: '#FFA500',
  },
  chipLow: {
    backgroundColor: theme.palette.grey[500],
  },
  chipNone: {
    backgroundColor: theme.palette.grey[300],
  },
}));

type DenseTableProps = {
  vulnList: any[];
};

export const DenseTable = ({ vulnList }: DenseTableProps) => {
  const classes = useStyles();

  const columns: TableColumn[] = [
    { title: 'Component Name', field: 'componentName' },
    { title: 'Component Version', field: 'componentVersionName' },
    { title: 'Severity', field: 'severity'},
    { title: 'Links', field: 'links'},
  ];

  const data = vulnList.map(item => {
    let gateColor;

    let riskPriorityDistribution = item.riskPriorityDistribution;
    let severity = Object.keys(riskPriorityDistribution).find(key => riskPriorityDistribution[key]===1)
    console.log(item._meta.links);
    switch (severity) {
      case 'CRITICAL': {
        gateColor = classes.chipCritical;
        break;
      }
      case 'HIGH': {
        gateColor = classes.chipHigh;
        break;
      }
      case 'MEDIUM': {
        gateColor = classes.chipMedium;
        break;
      }
      case 'LOW': {
        gateColor = classes.chipLow;
        break;
      }
      default: {
        severity = 'None'; 
        gateColor = classes.chipNone; 
        break;
      }
    }

    return {
      componentName: item.componentName,
      componentVersionName: item.componentVersionName,
      severity: (
        <Chip
          label={severity}
          classes={{ root: gateColor, label: classes.chipLabel }}
        />
      ),
      links: (
        <>
          {item._meta.links.map((link: { rel: React.Key | null | undefined; href: string; }) => (
            <Link key={link.rel} to={link.href}>
              {link.rel}<LaunchSharp /><br></br>
            </Link>
          ))}
        </>
      ),
    };
  });

  return (
    <Table
      title="Vulnerabilities"
      options={{ search: false, paging: false }}
      columns={columns}
      data={data}
    />
  );
};

export const BlackDuckPage = () => {
  return (
    <DenseTable vulnList={dataFromJson.items} />
  );
};
