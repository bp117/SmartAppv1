import { makeStyles } from '@material-ui/core/styles';
import React from 'react';
import LogoPNG from './wells.png'

const useStyles = makeStyles({
    img: {
      width: 'auto',
      height: 300,
      paddingLeft: 10,
      paddingRight: 10,
    },
  });

const LogoFullWF = () => {
    const classes = useStyles();
  
    return (<img className={classes.img} src={LogoPNG} /> );
  };

export default LogoFullWF;