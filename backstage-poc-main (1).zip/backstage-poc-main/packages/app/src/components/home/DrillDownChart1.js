/* eslint-disable new-cap */
import React, { useState } from 'react';

import {
    Card,
    CardContent,
    CardHeader,
    Typography,
    Grid,
    Divider,
    Box,
    useTheme,
    styled
  } from '@mui/material';
 
  import FusionCharts from 'fusioncharts';
  import Charts from 'fusioncharts/fusioncharts.charts';
  import ReactFC from 'react-fusioncharts';
  
  // Import the FusionCharts styles
  import 'fusioncharts/themes/fusioncharts.theme.fusion';
  
 // Add the charts module
Charts(FusionCharts);

// Set the initial chart data
const initialData = {
  chart: {
    caption: 'Services by Gating Criteria',
    subCaption: 'Click on a category to drill-down',
    showPercentValues: '1',
    theme: 'fusion',
    paletteColors: '#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000',
  },
  data: [
    { label: 'Cloud Readiness Met', value: '70' },
    { label: 'Cloud Readiness Not Met', value: '30' }
  ],
};

 const getDrillDownData = (selectedCategory) => {
    // Perform an API call or fetch data from your data source to get drill-down data based on the selected category
    // In this example, we're using static data for demonstration purposes

    const drillDownDataMap = {
      'Cloud Readiness Met': [
        { label: 'apifirst-metrics', value: '20' },
        { label: 'codebase-metrics', value: '20' },
        { label: 'telemetry-metrics', value: '20' },
        { label: 'concurrency-metrics', value: '20' },
        { label: 'config-metrics', value: '20' },
      ],
      'Cloud Readiness Not Met': [
        { label: 'apifirst-metrics', value: '5' },
        { label: 'codebase-metrics', value: '10' },
        { label: 'telemetry-metrics', value: '4' },
        { label: 'concurrency-metrics', value: '3' },
        { label: 'config-metrics', value: '1' },
      ]
    };

    return drillDownDataMap[selectedCategory] || [];
  };

const DrillDownChart = () => {
  const [chartData, setChartData] = useState(initialData);

  const handleDataClick = (eventObj, dataObj) => {
    const selectedCategory = dataObj.categoryLabel;
    const drillDownData = getDrillDownData(selectedCategory);

    // Create the drill-down chart configuration
    const drillDownConfig = {
      chart: {
        caption: 'Services by Gating Criteria',
        subCaption: `Category: ${selectedCategory}`,
        showvalues: '1',
        theme: 'fusion',
        paletteColors: '#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000',
      },
      data: drillDownData,
    };

    setChartData(drillDownConfig);
  };

 
  const handleBack = () => {
    setChartData(initialData);
  };
   
  return (
    <div>
          <Card  sx={{
      p: 2.5
    }}>
      <CardHeader  title='Cloud Readiness' />
      <Divider />
      <CardContent>
        <Grid container spacing={3}>
          <Grid
            md={12}
            item
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
   <div>
      {chartData === initialData ? (
        <ReactFC
          type="pie3d"
          width="600"
          height="400"
          dataFormat="JSON"
          dataSource={chartData}
          fcEvent-dataplotClick={handleDataClick}
        />
      ) : (
        <div>
          <ReactFC
            type="column2d"
            width="600"
            height="400"
            dataFormat="JSON"
            dataSource={chartData}
            fcEvent-dataplotClick={() => {}}
          />
          <button onClick={handleBack}>Back</button>
        </div>
      )}
    </div>
      </Grid>
      </Grid>
        </CardContent>
        </Card>
    </div>
  );
};

export default DrillDownChart;
