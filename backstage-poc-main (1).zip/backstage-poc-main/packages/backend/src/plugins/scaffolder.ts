import { createBuiltinActions } from '@backstage/plugin-scaffolder-backend';
import { ScmIntegrations } from '@backstage/integration';
// import { createNewFileAction } from './scaffolder/actions/custom';
import { PluginEnvironment } from '../types';
import { Router } from 'express-serve-static-core';
import { CatalogClient } from '@backstage/catalog-client';
import { createRouter } from '@backstage/plugin-scaffolder-backend';
import { generateZipAction } from './scaffolder/actions/generateZip';
import {createCustomFetchTemplateAction} from './scaffolder/actions/fetchTemplate'
import { addComponentToDatabase } from './scaffolder/actions/addComponentToDatabase'
import { create } from '@mui/material/styles/createTransitions';

export default async function createPlugin(
  env: PluginEnvironment,
): Promise<Router> {
  const catalogClient = new CatalogClient({ discoveryApi: env.discovery });
  const integrations = ScmIntegrations.fromConfig(env.config);

  const builtInActions = createBuiltinActions({
    integrations,
    catalogClient,
    config: env.config,
    reader: env.reader,
  });

  const actions = [...builtInActions,generateZipAction(),createCustomFetchTemplateAction({
    integrations,
    catalogClient,
    config: env.config,
    reader: env.reader,
  }),addComponentToDatabase()];

  return createRouter({
    actions,
    catalogClient: catalogClient,
    logger: env.logger,
    config: env.config,
    database: env.database,
    reader: env.reader,
  });
}
