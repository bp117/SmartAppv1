'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

import { CatalogClient } from '@backstage/catalog-client';
import { Config } from '@backstage/config';
import { createTemplateAction } from '@backstage/plugin-scaffolder-node';
import { zip } from 'zip-a-folder';

const path = require('path');
var fs = require('fs-extra');
const osHomedir = require('os-homedir');

var backendCommon = require('@backstage/backend-common');
var globby = require('globby');
var vm2 = require('vm2');
var isbinaryfile = require('isbinaryfile');

function _interopDefaultLegacy (e: any) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var fs__default = /*#__PURE__*/_interopDefaultLegacy(fs);
var path__default = /*#__PURE__*/_interopDefaultLegacy(path);
var globby__default = /*#__PURE__*/_interopDefaultLegacy(globby);

const pathOfZip = {
    title: "A URL to the repository with the provider",
    type: "string"
  };
  
  function containsSkippedContent(localOutputPath: string) {
    return localOutputPath === "" || localOutputPath.startsWith("/") || localOutputPath.includes("//");
  }
  
  async function fetchContents(options: { reader: any; integrations: any; baseUrl: any; fetchUrl: any; outputPath: any; }) {
    const { reader, integrations, baseUrl, fetchUrl = ".", outputPath } = options;
    let fetchUrlIsAbsolute = false;
    try {
      new URL(fetchUrl);
      fetchUrlIsAbsolute = true;
    } catch {
    }
    if (!fetchUrlIsAbsolute && (baseUrl == null ? void 0 : baseUrl.startsWith("file://"))) {
      const basePath = baseUrl.slice("file://".length);
      const srcDir = backendCommon.resolveSafeChildPath(path__default["default"].dirname(basePath), fetchUrl);
      await fs__default["default"].copy(srcDir, outputPath);
    } else {
      let readUrl;
      if (fetchUrlIsAbsolute) {
        readUrl = fetchUrl;
      } else if (baseUrl) {
        const integration = integrations.byUrl(baseUrl);
        if (!integration) {
          throw new Error(`No integration found for location ${baseUrl}`);
        }
        readUrl = integration.resolveUrl({
          url: fetchUrl,
          base: baseUrl
        });
      } else {
        throw new Error(
          `Failed to fetch, template location could not be determined and the fetch URL is relative, ${fetchUrl}`
        );
      }
      const res = await reader.readTree(readUrl);
      await fs__default["default"].ensureDir(outputPath);
      await res.dir({ targetDir: outputPath });
    }
  }

  const mkScript = (nunjucksSource: any) => `
const { render, renderCompat } = (() => {
  const module = {};
  const process = { env: {} };
  const require = (pkg) => { if (pkg === 'events') { return function (){}; }};

  ${nunjucksSource}

  const env = module.exports.configure({
    autoescape: false,
    tags: {
      variableStart: '\${{',
      variableEnd: '}}',
    },
  });

  const compatEnv = module.exports.configure({
    autoescape: false,
    tags: {
      variableStart: '{{',
      variableEnd: '}}',
    },
  });
  compatEnv.addFilter('jsonify', compatEnv.getFilter('dump'));

  if (typeof additionalTemplateFilters !== 'undefined') {
    for (const [filterName, filterFn] of Object.entries(additionalTemplateFilters)) {
      env.addFilter(filterName, (...args) => JSON.parse(filterFn(...args)));
    }
  }

  if (typeof additionalTemplateGlobals !== 'undefined') {
    for (const [globalName, global] of Object.entries(additionalTemplateGlobals)) {
      if (typeof global === 'function') {
        env.addGlobal(globalName, (...args) => JSON.parse(global(...args)));
      } else {
        env.addGlobal(globalName, JSON.parse(global));
      }
    }
  }

  let uninstallCompat = undefined;

  function render(str, values) {
    try {
      if (uninstallCompat) {
        uninstallCompat();
        uninstallCompat = undefined;
      }
      return env.renderString(str, JSON.parse(values));
    } catch (error) {
      // Make sure errors don't leak anything
      throw new Error(String(error.message));
    }
  }

  function renderCompat(str, values) {
    try {
      if (!uninstallCompat) {
        uninstallCompat = module.exports.installJinjaCompat();
      }
      return compatEnv.renderString(str, JSON.parse(values));
    } catch (error) {
      // Make sure errors don't leak anything
      throw new Error(String(error.message));
    }
  }

  return { render, renderCompat };
})();
`;

class SecureTemplater {
  static async loadRenderer(options = {}) {
    const {
      // parseRepoUrl,
      cookiecutterCompat,
      additionalTemplateFilters,
      additionalTemplateGlobals
    } = options;
    const sandbox = {};
    // if (parseRepoUrl) {
    //   sandbox.parseRepoUrl = (url: any) => JSON.stringify(parseRepoUrl(url));
    // }
    if (additionalTemplateFilters) {
      sandbox.additionalTemplateFilters = Object.fromEntries(
        Object.entries(additionalTemplateFilters).filter(([_, filterFunction]) => !!filterFunction).map(([filterName, filterFunction]) => [
          filterName,
          (...args: any) => JSON.stringify(filterFunction(...args))
        ])
      );
    }
    if (additionalTemplateGlobals) {
      sandbox.additionalTemplateGlobals = Object.fromEntries(
        Object.entries(additionalTemplateGlobals).filter(([_, global]) => !!global).map(([globalName, global]) => {
          if (typeof global === "function") {
            return [
              globalName,
              (...args: any) => JSON.stringify(global(...args))
            ];
          }
          return [globalName, JSON.stringify(global)];
        })
      );
    }
    const vm = new vm2.VM({ sandbox });
    const nunjucksSource = await fs__default["default"].readFile(
      backendCommon.resolvePackagePath(
        "@backstage/plugin-scaffolder-backend",
        "assets/nunjucks.js.txt"
      ),
      "utf-8"
    );
    vm.run(mkScript(nunjucksSource));
    const render = (template: any, values: any) => {
      if (!vm) {
        throw new Error("SecureTemplater has not been initialized");
      }
      vm.setGlobal("templateStr", template);
      vm.setGlobal("templateValues", JSON.stringify(values));
      if (cookiecutterCompat) {
        return vm.run(`renderCompat(templateStr, templateValues)`);
      }
      return vm.run(`render(templateStr, templateValues)`);
    };
    return render;
  }
}
export function createCustomFetchTemplateAction(options: { integrations: any; catalogClient?: CatalogClient; config?: Config; reader: any; additionalTemplateFilters?: any; additionalTemplateGlobals?: any; }) {
  const {
    reader,
    integrations,
    additionalTemplateFilters,
    additionalTemplateGlobals
  } = options;
  return createTemplateAction({
    id: "custom:fetch-template",
    description: "Downloads a skeleton, templates variables into file and directory names and content, and places the result in the workspace, or optionally in a subdirectory specified by the `targetPath` input option.",
    schema: {
      input: {
        type: "object",
        required: ["url"],
        properties: {
          url: {
            title: "Fetch URL",
            description: "Relative path or absolute URL pointing to the directory tree to fetch",
            type: "string"
          },
          targetPath: {
            title: "Target Path",
            description: "Target path within the working directory to download the contents to. Defaults to the working directory root.",
            type: "string"
          },
          values: {
            title: "Template Values",
            description: "Values to pass on to the templating engine",
            type: "object"
          },
          copyWithoutRender: {
            title: "[Deprecated] Copy Without Render",
            description: "An array of glob patterns. Any files or directories which match are copied without being processed as templates.",
            type: "array",
            items: {
              type: "string"
            }
          },
          copyWithoutTemplating: {
            title: "Copy Without Templating",
            description: "An array of glob patterns. Contents of matched files or directories are copied without being processed, but paths are subject to rendering.",
            type: "array",
            items: {
              type: "string"
            }
          },
          cookiecutterCompat: {
            title: "Cookiecutter compatibility mode",
            description: "Enable features to maximise compatibility with templates built for fetch:cookiecutter",
            type: "boolean"
          },
          templateFileExtension: {
            title: "Template File Extension",
            description: "If set, only files with the given extension will be templated. If set to `true`, the default extension `.njk` is used.",
            type: ["string", "boolean"]
          },
          replace: {
            title: "Replace files",
            description: "If set, replace files in targetPath instead of skipping existing ones.",
            type: "boolean"
          }
        }
      },
      output: {
        type: "object",
        properties: {
          pathOfZip: pathOfZip,
        },
      }, 

    },
    supportsDryRun: true,
    async handler(ctx) {
      var _a, _b;
      console.log("Fetching template content from remote URL");
      const homeDir = osHomedir()
      const workDir = path.join(homeDir,'Generated Files');
      const templateDir = backendCommon.resolveSafeChildPath(workDir, "template");
      const targetPath = (_a = ctx.input.targetPath) != null ? _a : "./";
      const outputDir = backendCommon.resolveSafeChildPath(workDir, targetPath);
      if (ctx.input.copyWithoutRender && ctx.input.copyWithoutTemplating) {
        throw new Error(
          "Fetch action input copyWithoutRender and copyWithoutTemplating can not be used at the same time"
        );
      }
      let copyOnlyPatterns;
      let renderFilename;
      if (ctx.input.copyWithoutRender) {
        ctx.logger.warn(
          "[Deprecated] Please use copyWithoutTemplating instead."
        );
        copyOnlyPatterns = ctx.input.copyWithoutRender;
        renderFilename = false;
      } else {
        copyOnlyPatterns = ctx.input.copyWithoutTemplating;
        renderFilename = true;
      }
      if (copyOnlyPatterns && !Array.isArray(copyOnlyPatterns)) {
        throw new Error(
          "Fetch action input copyWithoutRender/copyWithoutTemplating must be an Array"
        );
      }
      if (ctx.input.templateFileExtension && (copyOnlyPatterns || ctx.input.cookiecutterCompat)) {
        throw new Error(
          "Fetch action input extension incompatible with copyWithoutRender/copyWithoutTemplating and cookiecutterCompat"
        );
      }
      let extension = false;
      await fetchContents({
        reader,
        integrations,
        baseUrl: (_b = ctx.templateInfo) == null ? void 0 : _b.baseUrl,
        fetchUrl: ctx.input.url,
        outputPath: templateDir
      });
      console.log("Listing files and directories in template");
      const allEntriesInTemplate = await globby__default["default"](`**/*`, {
        cwd: templateDir,
        dot: true,
        onlyFiles: false,
        markDirectories: true,
        followSymbolicLinks: false
      });
      const nonTemplatedEntries = new Set(
        (await Promise.all(
          (copyOnlyPatterns || []).map(
            (pattern: any) => globby__default["default"](pattern, {
              cwd: templateDir,
              dot: true,
              onlyFiles: false,
              markDirectories: true,
              followSymbolicLinks: false
            })
          )
        )).flat()
      );
      const { cookiecutterCompat, values } = ctx.input;
      const context = {
        [cookiecutterCompat ? "cookiecutter" : "values"]: values
      };
      console.log(
        `Processing ${allEntriesInTemplate.length} template files/directories with input values`,
        ctx.input.values
      );
      const renderTemplate = await SecureTemplater.loadRenderer({
        cookiecutterCompat: ctx.input.cookiecutterCompat,
        additionalTemplateFilters,
        additionalTemplateGlobals
      });
      for (const location of allEntriesInTemplate) {
        let renderContents;
        let localOutputPath = location;
        if (extension) {
          renderContents = path.extname(localOutputPath) === extension;
          if (renderContents) {
            localOutputPath = localOutputPath.slice(0, -extension.length);
          }
          localOutputPath = renderTemplate(localOutputPath, context);
        } else {
          renderContents = !nonTemplatedEntries.has(location);
          if (renderFilename) {
            localOutputPath = renderTemplate(localOutputPath, context);
          } else {
            localOutputPath = renderContents ? renderTemplate(localOutputPath, context) : localOutputPath;
          }
        }
        if (containsSkippedContent(localOutputPath)) {
          continue;
        }
        const outputPath = backendCommon.resolveSafeChildPath(outputDir, localOutputPath);
        if (fs__default["default"].existsSync(outputPath) && !ctx.input.replace) {
          continue;
        }
        if (!renderContents && !extension) {
          console.log(
            `Copying file/directory ${location} without processing.`
          );
        }
        if (location.endsWith("/")) {
          console.log(
            `Writing directory ${location} to template output path.`
          );
          await fs__default["default"].ensureDir(outputPath);
        } else {
          const inputFilePath = backendCommon.resolveSafeChildPath(templateDir, location);
          const stats = await fs__default["default"].promises.lstat(inputFilePath);
          if (stats.isSymbolicLink() || await isbinaryfile.isBinaryFile(inputFilePath)) {
            console.log(
              `Copying file binary or symbolic link at ${location}, to template output path.`
            );
            await fs__default["default"].copy(inputFilePath, outputPath);
          } else {
            const statsObj = await fs__default["default"].stat(inputFilePath);
            console.log(
              `Writing file ${location} to template output path with mode ${statsObj.mode}.`
            );
            const inputFileContents = await fs__default["default"].readFile(inputFilePath, "utf-8");
            await fs__default["default"].outputFile(
              outputPath,
              renderContents ? renderTemplate(inputFileContents, context) : inputFileContents,
              { mode: statsObj.mode }
            );
          }
        }
      }
      ctx.output('pathOfZip',homeDir)
      console.log("The path is ",fs.existsSync(ctx.workspacePath))
      console.log(`Template result written to ${outputDir}`);
      console.log(`Template result written to ${workDir}`);
    }
  });
}; 