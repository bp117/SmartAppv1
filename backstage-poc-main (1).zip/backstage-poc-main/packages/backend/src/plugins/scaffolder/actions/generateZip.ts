import { createTemplateAction } from '@backstage/plugin-scaffolder-node';
import { zip } from 'zip-a-folder';

const path = require('path');
const fs = require('fs');

const url = {
  title: "A URL to the repository with the provider",
  type: "string"
};  

export const generateZipAction = () => {
  console.log('generateZipAction called');
  return createTemplateAction<{ directory: any }>({
    id: 'custom:generate-zip',
    schema: {
      input: {
        type: 'any',
        required: ['directory'],
        properties: {
          directory: {
            title: 'Directory',
            type: 'any',
            description: 'The directory to zip',
          },
        },
      },
      output: {
        type: "object",
        properties: {
          url: url,
        },
      },    
    }, 
    async handler(ctx) {   
      console.log(ctx.input)
      console.log(ctx.workspacePath)
      let directoryPath = ctx.input.directory.pathOfZip;
      let outputPath = path.join(directoryPath,'Generated Zips');

      if (!fs.existsSync(outputPath)) {
        fs.mkdirSync(outputPath);
      }
      
      outputPath = path.join(outputPath,`generated-${Date.now()}.zip`);
      directoryPath = path.join(directoryPath,'Generated Files')
      console.log("The path is ",fs.existsSync(outputPath)) 
      try {

           await zip(directoryPath, outputPath);
           console.log("The path in the generateZip is",outputPath)
           const encodedPath = Buffer.from(outputPath).toString('base64');
           ctx.output('url',`http://localhost:7007/api/my-custom-plugin/getZipFile/${encodedPath}`)

      } catch (error) {
        console.error(`Error zipping template: ${error}`);
        throw error;
      } 
    },   
  }); 
}; 