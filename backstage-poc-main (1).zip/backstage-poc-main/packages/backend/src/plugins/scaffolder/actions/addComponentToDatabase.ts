import { createTemplateAction } from '@backstage/plugin-scaffolder-node';
import axios from 'axios';

export const addComponentToDatabase = () => {
  return createTemplateAction<{
    name: string;
    appId: string;
  }>({
    id: 'custom:add-component-to-database',
    schema: {
      input: {
        type: 'object',
        required: ['name', 'appId'],
        properties: {
          name: {
            title: 'Name',
            type: 'string',
            description: 'The name of the component to add to the database',
          },
          appId: {
            title: 'App ID',
            type: 'string',
            description: 'The app ID of the component to add to the database',
          },
        },
      },
      output: {},
    },
    async handler(ctx) {
      const { name, appId } = ctx.input;
      console.log("This is the Name ", name);
      console.log("This is App Id")

      const url = `http://localhost:7007/api/my-custom-plugin/addCatalog/${name}/${appId}`;

      try {
        // Make an HTTP POST request to the specified URL
        await axios.post(url, { appId });

        // You can customize the response or output if needed

      } catch (error) {
        console.error(`Error adding component to the database: ${error}`);
        throw error;
      }
    },
  });
};
