import { errorHandler, PluginDatabaseManager } from '@backstage/backend-common';
import express, { response } from 'express';
import Router from 'express-promise-router';
import { Logger } from 'winston';
import { Config } from '@backstage/config';
import { resolvePackagePath } from '@backstage/backend-common';
import { Knex } from 'knex';

const path = require('path');
const fs = require('fs-extra');
const osHomedir = require('os-homedir');

export interface RouterOptions {
  logger: Logger;
  config: Config;
  database: PluginDatabaseManager;
}

export async function applyDatabaseMigrations(knex:Knex): Promise<void>{
  const migrationsDir = resolvePackagePath(
    'backstage-plugin-my-custom-plugin-backend',
    'migrations',
  );

  await knex.migrate.latest({
    directory: migrationsDir,
  });
}
export async function rollbackDatabaseMigrations(knex:Knex): Promise<void>{
  const migrationsDir = resolvePackagePath(
    'backstage-plugin-my-custom-plugin-backend',
    'migrations',
  );

  await knex.migrate.rollback({
    directory: migrationsDir,
  });
}

export async function downDatabaseMigrations(knex:Knex): Promise<void>{
  const migrationsDir = resolvePackagePath(
    'backstage-plugin-my-custom-plugin-backend',
    'migrations',
  );

  await knex.migrate.down({
    directory: migrationsDir,
  });
}



export async function createRouter(
  options: RouterOptions,
): Promise<express.Router> {

  const { logger,config,database } = options;

  const dbClient = await database.getClient();

   //await rollbackDatabaseMigrations(dbClient);
   //await downDatabaseMigrations(dbClient);
   await applyDatabaseMigrations(dbClient);


  const router = Router();
  router.use(express.json());

  router.get('/health', (_, response) => {
    logger.info('PONG!');
    response.json({ status: 'ok' });
  });

  router.get('/config/:configId',(request,response) => {
    const { configId } = request.params;
    logger.info("Got request to read config")
    const value = config.getOptionalString(`my-custom-plugin.${configId}`)
    response.send({response: value});
  });

  router.get('/db/showAll',async (request,response) => {
    //INSERT STUFF
    const returnValue = await dbClient('my-custom-table');
    logger.info(returnValue)
    response.send({response: returnValue})
  });

  router.get('/catalog/:catalogName/getAllDetails/:metrics',async (request,response) =>{
    
    const catalogName = request.params.catalogName;
    const metrics = request.params.metrics;

    const Asset_Master_Registry_result_array = await dbClient('Asset_Master_Registry').where('Asset_name',catalogName);
    const Asset_Id =  Asset_Master_Registry_result_array[0].Asset_Id;

    const Asset_Build_Info_result_Array = await dbClient('Asset_Build_Info').where('Asset_Id',Asset_Id);
    const Asset_Build_Id = Asset_Build_Info_result_Array[0].Asset_Build_Id;
    
    const Gating_Services_Data = await dbClient('Asset_Meta_Keys')
                                      .where('Asset_Build_Id',Asset_Build_Id)
                                      .where('metrics',metrics);

    
    response.send({response: Gating_Services_Data})
  })

  router.get('/catalog/:catalogName/summary', async (request,response) => {

    const catalogName = request.params.catalogName;
    const Asset_Master_Registry_result_array = await dbClient('Asset_Master_Registry').where('Asset_name',catalogName);
    console.log("array--1",Asset_Master_Registry_result_array);
    const Asset_Id =  Asset_Master_Registry_result_array[0].Asset_Id;
    console.log("assetid",Asset_Master_Registry_result_array[0].Asset_Id);
    const Asset_Build_Info_result_Array = await dbClient('Asset_Build_Info').where('Asset_Id',Asset_Id);
    console.log("array--2",Asset_Build_Info_result_Array);
    const Asset_Build_Id = Asset_Build_Info_result_Array[0].Asset_Build_Id;
    console.log("array--2buiildid",Asset_Build_Info_result_Array[0].Asset_Build_Id);
    
    const Gating_Services_Data = await dbClient('Asset_Meta_Keys').where('Asset_Build_Id',Asset_Build_Id);

    const Gating_Service_Summary = Gating_Services_Data.reduce((accumulator,currentValue)=>{
      const {metrics , ...rest} = currentValue
      const existingIndex = accumulator.findIndex((item: { metrics: any; }) => item.metrics === metrics)
      if(existingIndex === -1){
        accumulator.push(currentValue);
      }
      return accumulator;
},[])
  response.send({response: Gating_Service_Summary})
  })

  router.get('/catalog/:catalogName',async(req,res) => {
    const catalogName = req.params.catalogName;
    const Asset_Master_Registry_result_array = await dbClient('Asset_Master_Registry').where('Asset_name',catalogName);
    const Asset_Id =  Asset_Master_Registry_result_array[0].Asset_Id;
    res.send({response: Asset_Id});
  })

  router.get('/getZipFile/:zipFilePath',async(req,res) => {
    console.log("I got into getZipFile path")

    const encodedZipFilePath = req.params.zipFilePath
    const zipFilePath = Buffer.from(encodedZipFilePath, 'base64').toString('utf-8');
    const zipFileName =  `generated-${Date.now()}.zip`

    console.log("The path in router.ts is ",zipFilePath)

    res.download(zipFilePath,zipFileName,(err) =>{
      if(err){
        console.log(err)
      }
      else{
        const homeDir = osHomedir()
        const filesPath = path.join(homeDir,'Generated Files')
        const zipsPath = path.join(homeDir,'Generated Zips')

        fs.emptyDirSync(filesPath)
        fs.emptyDirSync(zipsPath)

        console.log("The zip is successfully downloaded")
      }
    })

  })

  router.post('/addCatalog/:catalogName/:catalogAppId', async (req, res) => {
    console.log("Hit the POST endpoint");
  
    try {
      const catalogName = req.params.catalogName;
      const catalogAppId = req.params.catalogAppId;
  
      // Perform database operation to insert the catalogName into Asset_Master_Registry table
      await dbClient('Asset_Master_Registry').insert({ Asset_name: catalogName ,App_id: catalogAppId});
  
      res.send("Success");
    } catch (error) {
      console.log(error);
      res.status(500).send("Error adding catalog to the database");
    }
  }); 

  router.use(errorHandler());
  return router;
}

