
exports.up = function(knex) {
    return knex.schema.createTable('Asset_Master_Registry', function(table) {
      table.string('Asset_Id').primary();
      table.string('Asset_name');
      table.dateTime('Date_Time').defaultTo(knex.fn.now());
      table.string('App_id');
      table.string('Repo_url');
      table.string('Owner_team');
    })
    .createTable('Asset_Build_Info', function(table) {
      table.string('Asset_Build_Id').primary().defaultTo(knex.raw("substr(replace(gen_random_uuid()::text, '-', ''), 1, 4)"));
      table.string('Asset_Id').notNullable();
      table.foreign('Asset_Id').references('Asset_Master_Registry.Asset_Id');
      table.dateTime('Date_Time').defaultTo(knex.fn.now());
      table.string('Env');
      table.string('Build_ref');
      table.string('Version');
    })
    .createTable('Asset_Meta_Keys',(table) => {
      table.string('Meta_key-id').primary().defaultTo(knex.raw("substr(replace(gen_random_uuid()::text, '-', ''), 1, 4)"));
      table.string('Asset_Build_Id').notNullable();
      table.foreign('Asset_Build_Id').references('Asset_Build_Info.Asset_Build_Id');
      table.string('metrics');
      table.string('summary_value');
      table.string('key');
      table.string('value');
    })
    .then(function() {
      return knex.raw(`
        CREATE OR REPLACE FUNCTION set_asset_id_default() RETURNS trigger AS $$
          BEGIN
            NEW."Asset_Id" := 'ms-' || NEW."App_id" || '-' || lpad(abs((random()*100000)::integer)::text, 5, '0');
            RETURN NEW;
          END;
        $$ LANGUAGE plpgsql;
      `);
    }).then(function() {
      return knex.raw(`
        CREATE TRIGGER set_asset_id_default_trigger
          BEFORE INSERT ON "Asset_Master_Registry"
          FOR EACH ROW
          EXECUTE FUNCTION set_asset_id_default();
      `);
    });
  };
  
  exports.down = function(knex) {
    return knex.schema.dropTable('Asset_Meta_Keys').dropTable('Asset_Build_Info').dropTable('Asset_Master_Registry');
  };