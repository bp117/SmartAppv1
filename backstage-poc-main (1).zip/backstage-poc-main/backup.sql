--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

-- Started on 2023-06-12 09:56:50

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 221 (class 1255 OID 24987)
-- Name: set_asset_id_default(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_asset_id_default() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
          BEGIN
            NEW."Asset_Id" := 'ms-' || NEW."App_id" || '-' || lpad(abs((random()*100000)::integer)::text, 5, '0');
            RETURN NEW;
          END;
        $$;


ALTER FUNCTION public.set_asset_id_default() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 41157)
-- Name: Asset_Build_Info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asset_Build_Info" (
    "Asset_Build_Id" character varying(255) DEFAULT substr(replace((gen_random_uuid())::text, '-'::text, ''::text), 1, 4) NOT NULL,
    "Asset_Id" character varying(255) NOT NULL,
    "Date_Time" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "Env" character varying(255),
    "Build_ref" character varying(255),
    "Version" character varying(255)
);


ALTER TABLE public."Asset_Build_Info" OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 41149)
-- Name: Asset_Master_Registry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asset_Master_Registry" (
    "Asset_Id" character varying(255) NOT NULL,
    "Asset_name" character varying(255),
    "Date_Time" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "App_id" character varying(255),
    "Repo_url" character varying(255),
    "Owner_team" character varying(255)
);


ALTER TABLE public."Asset_Master_Registry" OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 41171)
-- Name: Asset_Meta_Keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asset_Meta_Keys" (
    "Meta_key-id" character varying(255) DEFAULT substr(replace((gen_random_uuid())::text, '-'::text, ''::text), 1, 4) NOT NULL,
    "Asset_Build_Id" character varying(255) NOT NULL,
    metrics character varying(255),
    summary_value character varying(255),
    key character varying(255),
    value character varying(255)
);


ALTER TABLE public."Asset_Meta_Keys" OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 16922)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.knex_migrations OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 16921)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_id_seq OWNER TO postgres;

--
-- TOC entry 3364 (class 0 OID 0)
-- Dependencies: 214
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 217 (class 1259 OID 16929)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.knex_migrations_lock OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16928)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_lock_index_seq OWNER TO postgres;

--
-- TOC entry 3365 (class 0 OID 0)
-- Dependencies: 216
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 3191 (class 2604 OID 16925)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3192 (class 2604 OID 16932)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 3357 (class 0 OID 41157)
-- Dependencies: 219
-- Data for Name: Asset_Build_Info; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Asset_Build_Info" VALUES ('c175', 'ms-app-1-90806', '2023-03-15 16:52:58.883271+05:30', NULL, NULL, NULL);
INSERT INTO public."Asset_Build_Info" VALUES ('f3a7', 'ms-app-2-25256', '2023-03-15 16:53:52.179686+05:30', NULL, NULL, NULL);
INSERT INTO public."Asset_Build_Info" VALUES ('0cec', 'ms-app-3-86298', '2023-05-17 15:27:08.904872+05:30', NULL, NULL, NULL);
INSERT INTO public."Asset_Build_Info" VALUES ('c570', 'ms-app-4-17566', '2023-05-17 15:27:08.904872+05:30', NULL, NULL, NULL);
INSERT INTO public."Asset_Build_Info" VALUES ('47f6', 'ms-app-5-26674', '2023-05-17 15:27:08.904872+05:30', NULL, NULL, NULL);


--
-- TOC entry 3356 (class 0 OID 41149)
-- Dependencies: 218
-- Data for Name: Asset_Master_Registry; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-1-90806', 'accounts_service', '2023-03-15 16:52:24.145163+05:30', 'app-1', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-2-25256', 'payment-service', '2023-03-15 16:52:24.145163+05:30', 'app-2', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-4-17566', 'GSP', '2023-03-29 19:20:36.724207+05:30', 'app-4', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-5-26674', 'accounts_statement_service', '2023-03-29 19:20:36.724207+05:30', 'app-5', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-3-86298', 'sample', '2023-03-24 17:02:57.581471+05:30', 'app-3', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-test-1-48283', 'manideep', '2023-05-31 08:10:29.213484+05:30', 'test-1', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-9-90211', 'kanna', '2023-05-31 08:18:11.755953+05:30', 'app-9', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-10-97879', 'sample_node_app', '2023-05-31 08:24:23.486534+05:30', 'app-10', NULL, NULL);
INSERT INTO public."Asset_Master_Registry" VALUES ('ms-app-12-83063', 'Sample-1', '2023-05-31 15:22:43.117366+05:30', 'app-12', NULL, NULL);


--
-- TOC entry 3358 (class 0 OID 41171)
-- Dependencies: 220
-- Data for Name: Asset_Meta_Keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Asset_Meta_Keys" VALUES ('1291', '47f6', 'Security', 'Success', 'securityMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('23eb', '47f6', 'Security', 'Success', 'hasDTICoreLibrary', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('e42f', '47f6', 'Security', 'Success', 'aclFilterEnabled', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('aa65', '47f6', 'Codebase', 'Success', 'codebaseRepoMetrics', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('287c', 'c175', 'Data Isolation', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('5e7e', 'c175', 'Admin Processes', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('c403', 'c175', 'Disposability', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('6d35', 'c175', 'API First', 'Success', 'hasSpectralPlugin', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('84d3', 'c175', 'API First', 'Success', 'apiFirstMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('9391', 'c175', 'API First', 'Success', 'hasContract', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('8b22', 'c175', 'API First', 'Success', 'hasValidContractName', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('60d5', 'c175', 'Backing Metrics', 'Success', 'hasAnnotation', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('12be', 'c175', 'Backing Metrics', 'Success', 'hasUrl', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('824c', 'c175', 'CICD', 'Success', 'hasLatestEPLVersion', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('44a8', 'c175', 'CICD', 'Success', 'hasCICDFile', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('44a3', 'c175', 'CICD', 'Success', 'cicdMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('75d9', 'c175', 'CICD', 'Success', 'hasJenkinsFile', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('6bc4', 'c175', 'Telementry', 'Success', 'telementryMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('ed0a', 'c175', 'Telementry', 'Success', 'hasLogLibDepenedency', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('1e65', '47f6', 'Codebase', 'Success', 'codebaseRepoMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('e43d', 'c175', 'Stateless', 'Success', 'hasKeyword', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('3ad2', 'c175', 'Stateless', 'Success', 'hasGlobalStateProvider', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('3192', 'c175', 'Security', 'Success', 'aclFilterEnabled', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('2e1f', 'c175', 'Security', 'Success', 'hasDTICoreLibrary', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('5dca', 'c175', 'Security', 'Success', 'securityMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('91a7', 'c175', 'Parity', 'Fail', 'parityMetricValid', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('db6d', 'c175', 'Port', 'Success', 'hasPortHardcode', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('8763', 'c175', 'Port', 'Success', 'portMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('f315', 'c175', 'Parity', 'Fail', 'hasApplicationFileInBddTestResources', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('5e51', 'c175', 'Parity', 'Fail', 'cicdFilePresent', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('3af4', 'c175', 'Config', 'Success', 'systemSetPropertyUsed', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('195d', 'c175', 'Dependency', 'Success', 'dependencyMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('fd38', 'c175', 'Config', 'Success', 'systemGetPropertyUsed', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('3caa', 'c175', 'Config', 'Success', 'configMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('d075', 'c175', 'Config', 'Success', 'hasHardCodedURL', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('9ac5', 'c175', 'Codebase', 'Success', 'codebaseRepoFolderMetrics', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('1e99', 'c175', 'Codebase', 'Success', 'codebaseRepoMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('c1a9', 'c175', 'Codebase', 'Success', 'codebaseRepoMetrics', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('f081', 'f3a7', 'Security', 'Success', 'securityMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('5497', 'f3a7', 'Security', 'Success', 'hasDTICoreLibrary', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('cc9d', 'f3a7', 'Security', 'Success', 'aclFilterEnabled', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('6969', 'f3a7', 'Backing Metrics', 'Success', 'hasUrl', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('f255', 'f3a7', 'Backing Metrics', 'Success', 'hasAnnotation', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('4c76', 'f3a7', 'API First', 'Success', 'hasValidContractName', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('4c35', 'f3a7', 'API First', 'Success', 'hasContract', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('ab44', 'f3a7', 'API First', 'Success', 'apiFirstMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('28f3', 'f3a7', 'Data Isolation', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('4312', 'f3a7', 'Parity', 'Fail', 'cicdFilePresent', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('332c', 'f3a7', 'Parity', 'Fail', 'hasApplicationFileInBddTestResources', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('8d4d', 'f3a7', 'Parity', 'Fail', 'parityMetricValid', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('965a', '0cec', 'Parity', 'Fail', 'cicdFilePresent', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('5a1f', '0cec', 'Parity', 'Fail', 'hasApplicationFileInBddTestResources', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('6bf0', '0cec', 'Parity', 'Fail', 'parityMetricValid', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('6b9e', '0cec', 'Data Isolation', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('bf44', '0cec', 'Backing Metrics', 'Success', 'hasUrl', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('ac8c', '0cec', 'Backing Metrics', 'Success', 'hasAnnotation', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('36cf', '0cec', 'API First', 'Success', 'hasValidContractName', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('8386', '0cec', 'API First', 'Success', 'hasContract', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('b9bc', '0cec', 'API First', 'Success', 'apiFirstMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('1fd9', '0cec', 'Security', 'Success', 'securityMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('c952', '0cec', 'Security', 'Success', 'hasDTICoreLibrary', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('1732', '0cec', 'Security', 'Success', 'aclFilterEnabled', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('a014', '0cec', 'Codebase', 'Success', 'codebaseRepoMetrics', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('7886', '0cec', 'Codebase', 'Success', 'codebaseRepoMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('ff87', 'c570', 'Config', 'Success', 'configMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('0fc9', 'c570', 'Config', 'Success', 'systemGetPropertyUsed', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('36fb', 'c570', 'Parity', 'Fail', 'cicdFilePresent', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('bcc3', 'c570', 'Parity', 'Fail', 'hasApplicationFileInBddTestResources', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('6af9', 'c570', 'Port', 'Success', 'portMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('0eba', 'c570', 'Security', 'Success', 'securityMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('b47f', 'c570', 'Security', 'Success', 'hasDTICoreLibrary', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('5cba', 'c570', 'Security', 'Success', 'aclFilterEnabled', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('157b', 'c570', 'Stateless', 'Success', 'hasGlobalStateProvider', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('a13b', 'c570', 'Telementry', 'Success', 'hasLogLibDepenedency', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('36ca', 'c570', 'CICD', 'Success', 'cicdMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('8247', 'c570', 'CICD', 'Success', 'hasJenkinsFile', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('1fff', 'c570', 'CICD', 'Success', 'hasCICDFile', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('409e', '47f6', 'API First', 'Success', 'hasValidContractName', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('2ceb', '47f6', 'API First', 'Success', 'hasContract', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('c4e2', '47f6', 'API First', 'Success', 'apiFirstMetricValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('73cb', '47f6', 'Config', 'Success', 'hasHardCodedURL', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('8ac5', '47f6', 'Config', 'Success', 'configMetricsValid', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('7c83', '47f6', 'Config', 'Success', 'systemGetPropertyUsed', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('00a5', '47f6', 'Parity', 'Fail', 'cicdFilePresent', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('d37e', '47f6', 'Parity', 'Fail', 'hasApplicationFileInBddTestResources', 'False');
INSERT INTO public."Asset_Meta_Keys" VALUES ('4062', '47f6', 'Backing Metrics', 'Success', 'hasUrl', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('9316', '47f6', 'Backing Metrics', 'Success', 'hasAnnotation', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('c854', '47f6', 'Disposability', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('3034', '47f6', 'Data Isolation', 'NA', NULL, NULL);
INSERT INTO public."Asset_Meta_Keys" VALUES ('1581', 'c175', 'Logs', 'Success', 'hasConsoleAppender', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('b135', 'c175', 'Logs', 'Success', 'hasLogbackFile', 'True');
INSERT INTO public."Asset_Meta_Keys" VALUES ('5678', 'c570', 'Logs', 'Success', 'hasLogbackFile', 'True');


--
-- TOC entry 3353 (class 0 OID 16922)
-- Dependencies: 215
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.knex_migrations VALUES (28, '20230228092139_init.js', 1, '2023-03-15 16:49:56.662+05:30');


--
-- TOC entry 3355 (class 0 OID 16929)
-- Dependencies: 217
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.knex_migrations_lock VALUES (1, 0);


--
-- TOC entry 3366 (class 0 OID 0)
-- Dependencies: 214
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 28, true);


--
-- TOC entry 3367 (class 0 OID 0)
-- Dependencies: 216
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 3204 (class 2606 OID 41165)
-- Name: Asset_Build_Info Asset_Build_Info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset_Build_Info"
    ADD CONSTRAINT "Asset_Build_Info_pkey" PRIMARY KEY ("Asset_Build_Id");


--
-- TOC entry 3202 (class 2606 OID 41156)
-- Name: Asset_Master_Registry Asset_Master_Registry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset_Master_Registry"
    ADD CONSTRAINT "Asset_Master_Registry_pkey" PRIMARY KEY ("Asset_Id");


--
-- TOC entry 3206 (class 2606 OID 41178)
-- Name: Asset_Meta_Keys Asset_Meta_Keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset_Meta_Keys"
    ADD CONSTRAINT "Asset_Meta_Keys_pkey" PRIMARY KEY ("Meta_key-id");


--
-- TOC entry 3200 (class 2606 OID 16934)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3198 (class 2606 OID 16927)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3209 (class 2620 OID 41184)
-- Name: Asset_Master_Registry set_asset_id_default_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_asset_id_default_trigger BEFORE INSERT ON public."Asset_Master_Registry" FOR EACH ROW EXECUTE FUNCTION public.set_asset_id_default();


--
-- TOC entry 3207 (class 2606 OID 41166)
-- Name: Asset_Build_Info asset_build_info_asset_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset_Build_Info"
    ADD CONSTRAINT asset_build_info_asset_id_foreign FOREIGN KEY ("Asset_Id") REFERENCES public."Asset_Master_Registry"("Asset_Id");


--
-- TOC entry 3208 (class 2606 OID 41179)
-- Name: Asset_Meta_Keys asset_meta_keys_asset_build_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset_Meta_Keys"
    ADD CONSTRAINT asset_meta_keys_asset_build_id_foreign FOREIGN KEY ("Asset_Build_Id") REFERENCES public."Asset_Build_Info"("Asset_Build_Id");


-- Completed on 2023-06-12 09:56:50

--
-- PostgreSQL database dump complete
--

