// src/main/resources/js/my-script.js
AJS.$(document).on("click","#gpt-menu-link",function(e) {
    e.preventDefault();
  
    var issueKey = AJS.$("#key-val").text(); // Getting the current issue key


    var spinner = document.createElement('aui-spinner');
    spinner.setAttribute('size', 'large');

    var $container = AJS.$('#descriptionmodule_heading');
    $container.append(spinner);
 
    console.log("Making request to server for Issue:" + issueKey + " at " + new Date().toLocaleString())
    AJS.$.ajax({
        url: AJS.contextPath() + "/plugins/servlet/myservlet",
        type: "GET",
        timeout: 2*60*1000, //2 Minutes 
        data: { issueKey: issueKey , provider:"GPT"},
        success: function(response) {
            console.log("received response ", response)
            $container.find(spinner).remove();

            window.location.reload();
 
            // Handle successful response
            // $(document).reload();
     
        },
        error: function(xhr, status, error) {
            console.log("received error ", error + " at " + new Date().toLocaleString())
            $container.find(spinner).remove();

            // Handle error
        }
    });
 
    // AP.jira.refreshIssuePage();
}

);


AJS.$(document).on("click","#llama2-menu-link",function(e) {
    e.preventDefault();
  
    var issueKey = AJS.$("#key-val").text(); // Getting the current issue key


    var spinner = document.createElement('aui-spinner');
    spinner.setAttribute('size', 'large');

    var $container = AJS.$('#descriptionmodule_heading');
    $container.append(spinner);

    console.log("Making request to server for Issue:" + issueKey + " at " + new Date().toLocaleString())
    AJS.$.ajax({
        url: AJS.contextPath() + "/plugins/servlet/myservlet",
        type: "GET",
        timeout: 2*60*1000, //2 Minutes 
        data: { issueKey: issueKey, provider:"Llama2" },
        success: function(response) {
            console.log("received response ", response)
            $container.find(spinner).remove();

            window.location.reload();
 
            // Handle successful response
            // $(document).reload();
     
        },
        error: function(xhr, status, error) {
            console.log("received error ", error + " at " + new Date().toLocaleString())
            $container.find(spinner).remove();

            // Handle error
        }
    });
 
    // AP.jira.refreshIssuePage();
}

);



// AJS.$(document).ajaxStop(function(){
//     console.log("Triggering refresh")
//     window.location.reload();
// });


// AJS.toInit(function() {
//     console.log("Initializing AJS")

//     AJS.$(document).on("click","#review-link",function(){...


//     AJS.$("#example-menu-link").click(function(e) {
//         e.preventDefault();

//         console.log("Making request to server")

//         var issueKey = AJS.$("#issuekey-val").text(); // Getting the current issue key

//         AJS.$.ajax({
//             url: AJS.contextPath() + "/plugins/servlet/myservlet",
//             type: "GET",
//             data: { issueKey: issueKey },
//             success: function(response) {
//                 console.log("received response ", response)
//                 // Handle successful response
//             },
//             error: function(xhr, status, error) {
//                 console.log("received error ", error)
//                 // Handle error
//             }
//         });
//     });
// });
