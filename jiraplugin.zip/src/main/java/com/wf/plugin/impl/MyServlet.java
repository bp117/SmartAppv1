package com.wf.plugin.impl;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.attachment.Attachment;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.AttachmentUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String issueKey = req.getParameter("issueKey");
        String provider = req.getParameter("provider");
        System.out.println("Issuekey: " + issueKey);

        IssueManager issueManager = null;
        MutableIssue issue = null;
        String description = null;

        if (issueKey != null) {
            issueManager = ComponentAccessor.getIssueManager();
            issue = issueManager.getIssueObject(issueKey);

          if (issue != null) {
    description = issue.getDescription();
    JiraAuthenticationContext authContext = ComponentAccessor.getJiraAuthenticationContext();
    ApplicationUser user = authContext.getLoggedInUser();
    System.out.println("Description: " + description);
    
    Collection<Attachment> attachments = issue.getAttachments();
    List<String> base64Images = new ArrayList<>();
    attachments.forEach(attachment -> {
        if (attachment.getMimetype().startsWith("image/")) {
            File imageFile = AttachmentUtils.getAttachmentFile(attachment);
            Pattern pattern = Pattern.compile("\\\\(\\d+)$");
            Matcher matcher = pattern.matcher(imageFile.getAbsolutePath());
            if (matcher.find()) {
                String imageNumber = matcher.group(1);
                String newPath = String.format("D:\\Bindu\\gpt\\jirapoc\\jiraplugin\\target\\jira\\home\\data\\attachments\\PLUG\\10000\\PLUG-1\\thumbs\\_thumb_%s.png", imageNumber);
                Path imagePath = Paths.get(newPath);
                byte[] imageBytes = getBytes(imagePath.toString());
                String base64Image = Base64.getEncoder().encodeToString(imageBytes);
                base64Images.add(base64Image);
                //.out.println("Base64: " + base64Image);
            }
        }
        System.out.println("Attachment: " + attachment.getFilename());
    });

    if (!base64Images.isEmpty()) {
        IssueManager issueManager1 = ComponentAccessor.getIssueManager();
        final MutableIssue issue1 = issueManager1.getIssueObject(issueKey);
       
        issue1.setDescription(new RestClient().callAPI(base64Images, "GPT4"));
        issueManager1.updateIssue(user, issue1,
        com.atlassian.jira.event.type.EventDispatchOption.ISSUE_UPDATED, false);
        addComment(issue1, "Generated the user stories based on the UI mockups");
        // create user stories 

        // Notify the client to refresh the page
        resp.setContentType("text/html");
        try {
            resp.getWriter().write(issue1.getDescription());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return;
    }

   
}
        }

        // Notify the client to refresh the page
        resp.setContentType("text/html");
        // resp.getWriter().write("<script>window.location.reload();</script>");

        resp.getWriter().write(
                "Nothing received : from servlet " + issueKey + " " + issueManager + " " + issue + " " + description);
    }
    private String analyzeImage(File image) {
        // This method should implement the logic to send the image to an external analysis service
        // and return the analysis result. For demonstration, it returns a dummy response.
      //  new RestClient().callAPI(image, "GPT");
        return "Image analyzed successfully.";
    }

    private void addComment(Issue issue, String commentBody) {
        JiraAuthenticationContext authContext = ComponentAccessor.getJiraAuthenticationContext();
        ApplicationUser user = authContext.getLoggedInUser();
        ComponentAccessor.getCommentManager().create(issue, user, commentBody, false);
    }
    private byte[] getBytes(String filePath) {
        try {
            return Files.readAllBytes(Paths.get(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
