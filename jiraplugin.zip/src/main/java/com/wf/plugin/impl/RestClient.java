package com.wf.plugin.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.json.JSONObject;
import org.json.JSONArray;

public class RestClient {

    public String callAPI(List<String> value, String provider) { 
        JSONArray jsonArray = new JSONArray(value);
        String jsonInputString = String.format("{ \"message\" : %s , \"provider\" : \"%s\" }", jsonArray.toString(), provider);
        System.out.println("jsonInputString: " + jsonInputString);
        
       // String jsonInputString = "{ \"message\" : \"" + value + "\" , \"provider\" : \"" + provider + "\" }";
     try {
            URL url = new URL("http://127.0.0.1:5000/refine");

            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonInputString.getBytes( );
                os.write(input, 0, input.length);           
            }

            // Read the response
            StringBuilder response = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "utf-8"))) {
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
            }

            JSONObject jsonResponse = new JSONObject(response.toString());
            // Now you can access the elements of your JSON response
            System.out.println(jsonResponse.toString());

            return jsonResponse.getString("refined_story");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "no_change: " + jsonInputString;
    }
}

