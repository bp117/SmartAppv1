package com.wf.plugin.impl;


import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.attachment.Attachment;
import com.atlassian.jira.security.JiraAuthenticationContext;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.util.AttachmentUtils;
import com.atlassian.jira.web.action.JiraWebActionSupport;

import java.io.File;
import java.util.List;

public class ProcessImageAction extends JiraWebActionSupport {
    private final JiraAuthenticationContext authContext;

    public ProcessImageAction(JiraAuthenticationContext authContext) {
        this.authContext = authContext;
    }


    public String doDefault() throws Exception {
        String issueId = getHttpRequest().getParameter("issueId");
        Issue issue = ComponentAccessor.getIssueManager().getIssueObject(Long.parseLong(issueId));

        if (issue != null) {
            List<Attachment> attachments = ComponentAccessor.getAttachmentManager().getAttachments(issue);
            for (Attachment attachment : attachments) {
                if (attachment.getMimetype().startsWith("image/")) {
                    File imageFile = AttachmentUtils.getAttachmentFile(attachment);
                    String analysisResult = analyzeImage(imageFile);
                    addComment(issue, analysisResult);
                }
            }
        }

        return "success";
    }

    private String analyzeImage(File image) {
        // This method should implement the logic to send the image to an external analysis service
        // and return the analysis result. For demonstration, it returns a dummy response.
        return "Image analyzed successfully.";
    }

    private void addComment(Issue issue, String commentBody) {
        ApplicationUser user = authContext.getLoggedInUser();
        ComponentAccessor.getCommentManager().create(issue, user, commentBody, false);
    }
}
