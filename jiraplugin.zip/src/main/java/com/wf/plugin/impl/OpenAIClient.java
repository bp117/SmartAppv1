// package com.wf.plugin.impl;

// import com.theokanning.openai.completion.chat.ChatCompletionRequest;
// import com.theokanning.openai.completion.chat.ChatCompletionResult;
// import com.theokanning.openai.completion.chat.ChatCompletionChoice;

// import com.theokanning.openai.completion.chat.ChatMessage;
// import com.theokanning.openai.completion.chat.ChatMessageRole;
// import com.theokanning.openai.service.OpenAiService;
// import com.theokanning.openai.completion.CompletionRequest;

// import java.time.Duration;
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.List;

// public class OpenAIClient {
//     public String getRefinedUserStory(String storyDescription){
//         String token = "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";

//         OpenAiService service = new OpenAiService(token, Duration.ofSeconds(30));
 
//         System.out.println("Streaming chat completion...");
//         final List<ChatMessage> messages = new ArrayList<>();
//         final ChatMessage systemMessage = new ChatMessage(ChatMessageRole.SYSTEM.value(), "You are an agile coach who strictly reviews the JIRA stories to complaint with INVEST principles. Also good rewriting the user story inline with INVEST, provide acceptance criteria, BDD Test cases and synthetic test data. ");
//         messages.add(systemMessage);
//         final ChatMessage storyDesc = new ChatMessage(ChatMessageRole.USER.value(), "Validate following user story for INVEST principles and rewrite it to follow it along with clear acceptance criteria, BDD Test cases and synthetic test data. This will be used as it is in JIRA story board. So provide necessary formatting. " + "\nStory:\n" + storyDescription);
        
//         ChatCompletionRequest chatCompletionRequest = ChatCompletionRequest
//                 .builder()
//                 .model("gpt-3.5-turbo")
//                 .messages(messages)
//                 .n(1)
//                 .maxTokens(500)
//                 .logitBias(new HashMap<>())
//                 .build();

//         ChatMessage responseMessage = service.createChatCompletion(chatCompletionRequest).getChoices().get(0).getMessage();
//         messages.add(responseMessage); // don't forget to update the conversation with the latest response

//         String response = responseMessage.getContent();

//         // List<ChatCompletionChoice> result = service.createChatCompletion(chatCompletionRequest).getChoices();

//         // System.out.println(result.get(0).message.content);

//         System.out.println("Response " + response);
//         service.shutdownExecutor();

//         return response;
//     }
// }