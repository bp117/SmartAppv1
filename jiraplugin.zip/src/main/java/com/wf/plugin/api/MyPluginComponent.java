package com.wf.plugin.api;

public interface MyPluginComponent {
    String getName();
}